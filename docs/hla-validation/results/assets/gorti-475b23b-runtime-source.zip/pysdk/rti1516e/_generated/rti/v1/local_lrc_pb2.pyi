from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class LocalLRCRequest(_message.Message):
    __slots__ = ("open", "attribute_update", "interaction", "flush", "batch")
    OPEN_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_UPDATE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_FIELD_NUMBER: _ClassVar[int]
    FLUSH_FIELD_NUMBER: _ClassVar[int]
    BATCH_FIELD_NUMBER: _ClassVar[int]
    open: LocalLRCOpen
    attribute_update: LocalLRCAttributeUpdate
    interaction: LocalLRCInteraction
    flush: LocalLRCFlush
    batch: LocalLRCBatch
    def __init__(self, open: _Optional[_Union[LocalLRCOpen, _Mapping]] = ..., attribute_update: _Optional[_Union[LocalLRCAttributeUpdate, _Mapping]] = ..., interaction: _Optional[_Union[LocalLRCInteraction, _Mapping]] = ..., flush: _Optional[_Union[LocalLRCFlush, _Mapping]] = ..., batch: _Optional[_Union[LocalLRCBatch, _Mapping]] = ...) -> None: ...

class LocalLRCOpen(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "expected_federation_generation", "ack_every", "requested_max_batch_operations")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_FEDERATION_GENERATION_FIELD_NUMBER: _ClassVar[int]
    ACK_EVERY_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_MAX_BATCH_OPERATIONS_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    expected_federation_generation: int
    ack_every: int
    requested_max_batch_operations: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., expected_federation_generation: _Optional[int] = ..., ack_every: _Optional[int] = ..., requested_max_batch_operations: _Optional[int] = ...) -> None: ...

class LocalLRCAttributeUpdate(_message.Message):
    __slots__ = ("sequence", "object_handle", "attributes")
    class AttributesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: bytes
        def __init__(self, key: _Optional[int] = ..., value: _Optional[bytes] = ...) -> None: ...
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    sequence: int
    object_handle: int
    attributes: _containers.ScalarMap[int, bytes]
    def __init__(self, sequence: _Optional[int] = ..., object_handle: _Optional[int] = ..., attributes: _Optional[_Mapping[int, bytes]] = ...) -> None: ...

class LocalLRCInteraction(_message.Message):
    __slots__ = ("sequence", "interaction_class_handle", "parameters")
    class ParametersEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: bytes
        def __init__(self, key: _Optional[int] = ..., value: _Optional[bytes] = ...) -> None: ...
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    sequence: int
    interaction_class_handle: int
    parameters: _containers.ScalarMap[int, bytes]
    def __init__(self, sequence: _Optional[int] = ..., interaction_class_handle: _Optional[int] = ..., parameters: _Optional[_Mapping[int, bytes]] = ...) -> None: ...

class LocalLRCOperation(_message.Message):
    __slots__ = ("attribute_update", "interaction")
    ATTRIBUTE_UPDATE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_FIELD_NUMBER: _ClassVar[int]
    attribute_update: LocalLRCAttributeUpdate
    interaction: LocalLRCInteraction
    def __init__(self, attribute_update: _Optional[_Union[LocalLRCAttributeUpdate, _Mapping]] = ..., interaction: _Optional[_Union[LocalLRCInteraction, _Mapping]] = ...) -> None: ...

class LocalLRCBatch(_message.Message):
    __slots__ = ("operations",)
    OPERATIONS_FIELD_NUMBER: _ClassVar[int]
    operations: _containers.RepeatedCompositeFieldContainer[LocalLRCOperation]
    def __init__(self, operations: _Optional[_Iterable[_Union[LocalLRCOperation, _Mapping]]] = ...) -> None: ...

class LocalLRCFlush(_message.Message):
    __slots__ = ("through_sequence",)
    THROUGH_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    through_sequence: int
    def __init__(self, through_sequence: _Optional[int] = ...) -> None: ...

class LocalLRCAck(_message.Message):
    __slots__ = ("committed_through", "ack_every", "max_batch_operations")
    COMMITTED_THROUGH_FIELD_NUMBER: _ClassVar[int]
    ACK_EVERY_FIELD_NUMBER: _ClassVar[int]
    MAX_BATCH_OPERATIONS_FIELD_NUMBER: _ClassVar[int]
    committed_through: int
    ack_every: int
    max_batch_operations: int
    def __init__(self, committed_through: _Optional[int] = ..., ack_every: _Optional[int] = ..., max_batch_operations: _Optional[int] = ...) -> None: ...
