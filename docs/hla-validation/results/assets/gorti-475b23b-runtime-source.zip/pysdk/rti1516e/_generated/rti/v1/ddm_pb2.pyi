from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class LookupRoutingSpaceRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., name: _Optional[str] = ...) -> None: ...

class LookupRoutingSpaceResponse(_message.Message):
    __slots__ = ("routing_space_handle", "found")
    ROUTING_SPACE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    FOUND_FIELD_NUMBER: _ClassVar[int]
    routing_space_handle: int
    found: bool
    def __init__(self, routing_space_handle: _Optional[int] = ..., found: _Optional[bool] = ...) -> None: ...

class LookupDimensionRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "routing_space_handle", "name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    ROUTING_SPACE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    routing_space_handle: int
    name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., routing_space_handle: _Optional[int] = ..., name: _Optional[str] = ...) -> None: ...

class LookupDimensionResponse(_message.Message):
    __slots__ = ("dimension_handle", "found")
    DIMENSION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    FOUND_FIELD_NUMBER: _ClassVar[int]
    dimension_handle: int
    found: bool
    def __init__(self, dimension_handle: _Optional[int] = ..., found: _Optional[bool] = ...) -> None: ...

class CreateRegionRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "routing_space_handle", "dimension_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ROUTING_SPACE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    routing_space_handle: int
    dimension_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., routing_space_handle: _Optional[int] = ..., dimension_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class CreateRegionResponse(_message.Message):
    __slots__ = ("region_handle",)
    REGION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    region_handle: int
    def __init__(self, region_handle: _Optional[int] = ...) -> None: ...

class Range(_message.Message):
    __slots__ = ("lower", "upper")
    LOWER_FIELD_NUMBER: _ClassVar[int]
    UPPER_FIELD_NUMBER: _ClassVar[int]
    lower: int
    upper: int
    def __init__(self, lower: _Optional[int] = ..., upper: _Optional[int] = ...) -> None: ...

class SetRangeBoundsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "region_handle", "dimension_handle", "bounds")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    BOUNDS_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    region_handle: int
    dimension_handle: int
    bounds: Range
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., region_handle: _Optional[int] = ..., dimension_handle: _Optional[int] = ..., bounds: _Optional[_Union[Range, _Mapping]] = ...) -> None: ...

class CommitRegionRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "region_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    region_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., region_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class DeleteRegionRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "region_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    region_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., region_handle: _Optional[int] = ...) -> None: ...

class QueryBoundsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "region_handle", "dimension_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    region_handle: int
    dimension_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., region_handle: _Optional[int] = ..., dimension_handle: _Optional[int] = ...) -> None: ...

class QueryBoundsResponse(_message.Message):
    __slots__ = ("bounds", "found")
    BOUNDS_FIELD_NUMBER: _ClassVar[int]
    FOUND_FIELD_NUMBER: _ClassVar[int]
    bounds: Range
    found: bool
    def __init__(self, bounds: _Optional[_Union[Range, _Mapping]] = ..., found: _Optional[bool] = ...) -> None: ...

class SubscribeOCAWithRegionsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_class_handle", "attribute_handles", "region_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_class_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    region_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ..., region_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class SubscribeICWithRegionsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "interaction_class_handle", "region_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    interaction_class_handle: int
    region_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., interaction_class_handle: _Optional[int] = ..., region_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class AttributeRegions(_message.Message):
    __slots__ = ("attribute_handle", "region_handles")
    ATTRIBUTE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    attribute_handle: int
    region_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, attribute_handle: _Optional[int] = ..., region_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class RegisterObjectWithRegionsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_class_handle", "object_name", "attribute_regions")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_REGIONS_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_class_handle: int
    object_name: str
    attribute_regions: _containers.RepeatedCompositeFieldContainer[AttributeRegions]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., object_name: _Optional[str] = ..., attribute_regions: _Optional[_Iterable[_Union[AttributeRegions, _Mapping]]] = ...) -> None: ...

class RegisterObjectWithRegionsResponse(_message.Message):
    __slots__ = ("object_handle", "object_name")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    object_name: str
    def __init__(self, object_handle: _Optional[int] = ..., object_name: _Optional[str] = ...) -> None: ...

class AssociateRegionsForUpdatesRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attribute_regions")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_REGIONS_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attribute_regions: _containers.RepeatedCompositeFieldContainer[AttributeRegions]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attribute_regions: _Optional[_Iterable[_Union[AttributeRegions, _Mapping]]] = ...) -> None: ...

class UnassociateRegionsForUpdatesRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attribute_regions")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_REGIONS_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attribute_regions: _containers.RepeatedCompositeFieldContainer[AttributeRegions]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attribute_regions: _Optional[_Iterable[_Union[AttributeRegions, _Mapping]]] = ...) -> None: ...

class UnsubscribeOCAWithRegionsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_class_handle", "attribute_handles", "region_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_class_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    region_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ..., region_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class UnsubscribeICWithRegionsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "interaction_class_handle", "region_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    interaction_class_handle: int
    region_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., interaction_class_handle: _Optional[int] = ..., region_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class SendInteractionWithRegionsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "interaction_class_handle", "parameters", "logical_time", "region_handles")
    class ParametersEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: bytes
        def __init__(self, key: _Optional[int] = ..., value: _Optional[bytes] = ...) -> None: ...
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    interaction_class_handle: int
    parameters: _containers.ScalarMap[int, bytes]
    logical_time: float
    region_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., interaction_class_handle: _Optional[int] = ..., parameters: _Optional[_Mapping[int, bytes]] = ..., logical_time: _Optional[float] = ..., region_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class RequestAttributeValueUpdateWithRegionsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_class_handle", "attribute_handles", "region_handles", "user_supplied_tag")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    USER_SUPPLIED_TAG_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_class_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    region_handles: _containers.RepeatedScalarFieldContainer[int]
    user_supplied_tag: bytes
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ..., region_handles: _Optional[_Iterable[int]] = ..., user_supplied_tag: _Optional[bytes] = ...) -> None: ...

class DDMRangeEntry(_message.Message):
    __slots__ = ("dimension_handle", "lower", "upper")
    DIMENSION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOWER_FIELD_NUMBER: _ClassVar[int]
    UPPER_FIELD_NUMBER: _ClassVar[int]
    dimension_handle: int
    lower: int
    upper: int
    def __init__(self, dimension_handle: _Optional[int] = ..., lower: _Optional[int] = ..., upper: _Optional[int] = ...) -> None: ...

class DDMRegionEntry(_message.Message):
    __slots__ = ("region_handle", "owner_federate", "routing_space_handle", "dimension_handles", "committed", "pending")
    REGION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OWNER_FEDERATE_FIELD_NUMBER: _ClassVar[int]
    ROUTING_SPACE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    COMMITTED_FIELD_NUMBER: _ClassVar[int]
    PENDING_FIELD_NUMBER: _ClassVar[int]
    region_handle: int
    owner_federate: int
    routing_space_handle: int
    dimension_handles: _containers.RepeatedScalarFieldContainer[int]
    committed: _containers.RepeatedCompositeFieldContainer[DDMRangeEntry]
    pending: _containers.RepeatedCompositeFieldContainer[DDMRangeEntry]
    def __init__(self, region_handle: _Optional[int] = ..., owner_federate: _Optional[int] = ..., routing_space_handle: _Optional[int] = ..., dimension_handles: _Optional[_Iterable[int]] = ..., committed: _Optional[_Iterable[_Union[DDMRangeEntry, _Mapping]]] = ..., pending: _Optional[_Iterable[_Union[DDMRangeEntry, _Mapping]]] = ...) -> None: ...

class DDMSubscriptionEntry(_message.Message):
    __slots__ = ("object_class_handle", "attribute_handle", "subscriber_federate", "region_handles")
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    SUBSCRIBER_FEDERATE_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    object_class_handle: int
    attribute_handle: int
    subscriber_federate: int
    region_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, object_class_handle: _Optional[int] = ..., attribute_handle: _Optional[int] = ..., subscriber_federate: _Optional[int] = ..., region_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class DDMInteractionSubscriptionEntry(_message.Message):
    __slots__ = ("interaction_class_handle", "subscriber_federate", "region_handles")
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    SUBSCRIBER_FEDERATE_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    interaction_class_handle: int
    subscriber_federate: int
    region_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, interaction_class_handle: _Optional[int] = ..., subscriber_federate: _Optional[int] = ..., region_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class DDMObjectPublicationEntry(_message.Message):
    __slots__ = ("object_handle", "attribute_handle", "region_handles")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    REGION_HANDLES_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    attribute_handle: int
    region_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, object_handle: _Optional[int] = ..., attribute_handle: _Optional[int] = ..., region_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class DDMManagerState(_message.Message):
    __slots__ = ("next_region_handle", "regions", "object_subscriptions", "interaction_subscriptions", "object_publications")
    NEXT_REGION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    REGIONS_FIELD_NUMBER: _ClassVar[int]
    OBJECT_SUBSCRIPTIONS_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_SUBSCRIPTIONS_FIELD_NUMBER: _ClassVar[int]
    OBJECT_PUBLICATIONS_FIELD_NUMBER: _ClassVar[int]
    next_region_handle: int
    regions: _containers.RepeatedCompositeFieldContainer[DDMRegionEntry]
    object_subscriptions: _containers.RepeatedCompositeFieldContainer[DDMSubscriptionEntry]
    interaction_subscriptions: _containers.RepeatedCompositeFieldContainer[DDMInteractionSubscriptionEntry]
    object_publications: _containers.RepeatedCompositeFieldContainer[DDMObjectPublicationEntry]
    def __init__(self, next_region_handle: _Optional[int] = ..., regions: _Optional[_Iterable[_Union[DDMRegionEntry, _Mapping]]] = ..., object_subscriptions: _Optional[_Iterable[_Union[DDMSubscriptionEntry, _Mapping]]] = ..., interaction_subscriptions: _Optional[_Iterable[_Union[DDMInteractionSubscriptionEntry, _Mapping]]] = ..., object_publications: _Optional[_Iterable[_Union[DDMObjectPublicationEntry, _Mapping]]] = ...) -> None: ...
