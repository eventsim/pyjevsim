from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SaveState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SAVE_STATE_UNSPECIFIED: _ClassVar[SaveState]
    SAVE_STATE_IDLE: _ClassVar[SaveState]
    SAVE_STATE_INITIATED: _ClassVar[SaveState]
    SAVE_STATE_SAVED: _ClassVar[SaveState]
    SAVE_STATE_NOT_SAVED: _ClassVar[SaveState]

class RestoreState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RESTORE_STATE_UNSPECIFIED: _ClassVar[RestoreState]
    RESTORE_STATE_IDLE: _ClassVar[RestoreState]
    RESTORE_STATE_LOADING: _ClassVar[RestoreState]
    RESTORE_STATE_INITIATED: _ClassVar[RestoreState]
    RESTORE_STATE_COMPLETED: _ClassVar[RestoreState]
    RESTORE_STATE_FAILED: _ClassVar[RestoreState]
SAVE_STATE_UNSPECIFIED: SaveState
SAVE_STATE_IDLE: SaveState
SAVE_STATE_INITIATED: SaveState
SAVE_STATE_SAVED: SaveState
SAVE_STATE_NOT_SAVED: SaveState
RESTORE_STATE_UNSPECIFIED: RestoreState
RESTORE_STATE_IDLE: RestoreState
RESTORE_STATE_LOADING: RestoreState
RESTORE_STATE_INITIATED: RestoreState
RESTORE_STATE_COMPLETED: RestoreState
RESTORE_STATE_FAILED: RestoreState

class AbortFederationSaveRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...

class AbortFederationRestoreRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...

class RequestFederationSaveRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "label", "save_time")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    SAVE_TIME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    label: str
    save_time: float
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., label: _Optional[str] = ..., save_time: _Optional[float] = ...) -> None: ...

class FederateSaveResponseRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...

class QuerySaveStateRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "label")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    label: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., label: _Optional[str] = ...) -> None: ...

class QuerySaveStateResponse(_message.Message):
    __slots__ = ("state",)
    STATE_FIELD_NUMBER: _ClassVar[int]
    state: SaveState
    def __init__(self, state: _Optional[_Union[SaveState, str]] = ...) -> None: ...

class RequestFederationRestoreRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "label")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    label: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., label: _Optional[str] = ...) -> None: ...

class FederateRestoreResponseRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...

class QueryRestoreStateRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "label")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    label: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., label: _Optional[str] = ...) -> None: ...

class QueryRestoreStateResponse(_message.Message):
    __slots__ = ("state",)
    STATE_FIELD_NUMBER: _ClassVar[int]
    state: RestoreState
    def __init__(self, state: _Optional[_Union[RestoreState, str]] = ...) -> None: ...
