from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PubObjAttrsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_class_handle", "attribute_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_class_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class UnpubObjAttrsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_class_handle", "attribute_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_class_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class SubObjAttrsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_class_handle", "attribute_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_class_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class UnsubObjAttrsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_class_handle", "attribute_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_class_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class PubInterRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "interaction_class_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    interaction_class_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., interaction_class_handle: _Optional[int] = ...) -> None: ...

class UnpubInterRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "interaction_class_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    interaction_class_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., interaction_class_handle: _Optional[int] = ...) -> None: ...

class SubInterRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "interaction_class_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    interaction_class_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., interaction_class_handle: _Optional[int] = ...) -> None: ...

class UnsubInterRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "interaction_class_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    interaction_class_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., interaction_class_handle: _Optional[int] = ...) -> None: ...
