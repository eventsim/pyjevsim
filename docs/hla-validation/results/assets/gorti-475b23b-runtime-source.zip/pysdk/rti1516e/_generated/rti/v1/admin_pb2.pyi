from rti.v1 import common_pb2 as _common_pb2
from rti.v1 import federation_pb2 as _federation_pb2
from rti.v1 import savepoint_pb2 as _savepoint_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SyncPointState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SYNC_POINT_STATE_UNSPECIFIED: _ClassVar[SyncPointState]
    SYNC_POINT_STATE_ANNOUNCED: _ClassVar[SyncPointState]
    SYNC_POINT_STATE_ACHIEVED: _ClassVar[SyncPointState]
SYNC_POINT_STATE_UNSPECIFIED: SyncPointState
SYNC_POINT_STATE_ANNOUNCED: SyncPointState
SYNC_POINT_STATE_ACHIEVED: SyncPointState

class StatusRequest(_message.Message):
    __slots__ = ("wire_version",)
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ...) -> None: ...

class StatusResponse(_message.Message):
    __slots__ = ("rtid_version", "uptime_seconds")
    RTID_VERSION_FIELD_NUMBER: _ClassVar[int]
    UPTIME_SECONDS_FIELD_NUMBER: _ClassVar[int]
    rtid_version: str
    uptime_seconds: int
    def __init__(self, rtid_version: _Optional[str] = ..., uptime_seconds: _Optional[int] = ...) -> None: ...

class SnapshotRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ...) -> None: ...

class SnapshotResponse(_message.Message):
    __slots__ = ("rtid_version", "uptime_seconds", "federations")
    RTID_VERSION_FIELD_NUMBER: _ClassVar[int]
    UPTIME_SECONDS_FIELD_NUMBER: _ClassVar[int]
    FEDERATIONS_FIELD_NUMBER: _ClassVar[int]
    rtid_version: str
    uptime_seconds: int
    federations: _containers.RepeatedCompositeFieldContainer[FederationSnapshot]
    def __init__(self, rtid_version: _Optional[str] = ..., uptime_seconds: _Optional[int] = ..., federations: _Optional[_Iterable[_Union[FederationSnapshot, _Mapping]]] = ...) -> None: ...

class FederationSnapshot(_message.Message):
    __slots__ = ("name", "mode", "federates_joined", "federates", "time", "sync_points", "save_state", "restore_state", "region_count", "object_instance_count", "published_classes", "transport_mode", "dds_domain_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    FEDERATES_JOINED_FIELD_NUMBER: _ClassVar[int]
    FEDERATES_FIELD_NUMBER: _ClassVar[int]
    TIME_FIELD_NUMBER: _ClassVar[int]
    SYNC_POINTS_FIELD_NUMBER: _ClassVar[int]
    SAVE_STATE_FIELD_NUMBER: _ClassVar[int]
    RESTORE_STATE_FIELD_NUMBER: _ClassVar[int]
    REGION_COUNT_FIELD_NUMBER: _ClassVar[int]
    OBJECT_INSTANCE_COUNT_FIELD_NUMBER: _ClassVar[int]
    PUBLISHED_CLASSES_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_MODE_FIELD_NUMBER: _ClassVar[int]
    DDS_DOMAIN_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    mode: _common_pb2.Mode
    federates_joined: int
    federates: _containers.RepeatedCompositeFieldContainer[FederateSnapshot]
    time: TimeSnapshot
    sync_points: _containers.RepeatedCompositeFieldContainer[SyncPointSnapshot]
    save_state: _savepoint_pb2.SaveState
    restore_state: _savepoint_pb2.RestoreState
    region_count: int
    object_instance_count: int
    published_classes: _containers.RepeatedScalarFieldContainer[int]
    transport_mode: _federation_pb2.TransportMode
    dds_domain_id: int
    def __init__(self, name: _Optional[str] = ..., mode: _Optional[_Union[_common_pb2.Mode, str]] = ..., federates_joined: _Optional[int] = ..., federates: _Optional[_Iterable[_Union[FederateSnapshot, _Mapping]]] = ..., time: _Optional[_Union[TimeSnapshot, _Mapping]] = ..., sync_points: _Optional[_Iterable[_Union[SyncPointSnapshot, _Mapping]]] = ..., save_state: _Optional[_Union[_savepoint_pb2.SaveState, str]] = ..., restore_state: _Optional[_Union[_savepoint_pb2.RestoreState, str]] = ..., region_count: _Optional[int] = ..., object_instance_count: _Optional[int] = ..., published_classes: _Optional[_Iterable[int]] = ..., transport_mode: _Optional[_Union[_federation_pb2.TransportMode, str]] = ..., dds_domain_id: _Optional[int] = ...) -> None: ...

class FederateSnapshot(_message.Message):
    __slots__ = ("handle", "name", "current_time", "pending_request_time", "lookahead", "regulating", "constrained", "published_object_classes", "subscribed_object_classes", "published_interaction_classes", "subscribed_interaction_classes", "updates_sent", "interactions_sent", "reflections_received", "interactions_received", "drops_total", "outbox_queue_depth", "outbox_capacity", "join_unix_seconds")
    HANDLE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CURRENT_TIME_FIELD_NUMBER: _ClassVar[int]
    PENDING_REQUEST_TIME_FIELD_NUMBER: _ClassVar[int]
    LOOKAHEAD_FIELD_NUMBER: _ClassVar[int]
    REGULATING_FIELD_NUMBER: _ClassVar[int]
    CONSTRAINED_FIELD_NUMBER: _ClassVar[int]
    PUBLISHED_OBJECT_CLASSES_FIELD_NUMBER: _ClassVar[int]
    SUBSCRIBED_OBJECT_CLASSES_FIELD_NUMBER: _ClassVar[int]
    PUBLISHED_INTERACTION_CLASSES_FIELD_NUMBER: _ClassVar[int]
    SUBSCRIBED_INTERACTION_CLASSES_FIELD_NUMBER: _ClassVar[int]
    UPDATES_SENT_FIELD_NUMBER: _ClassVar[int]
    INTERACTIONS_SENT_FIELD_NUMBER: _ClassVar[int]
    REFLECTIONS_RECEIVED_FIELD_NUMBER: _ClassVar[int]
    INTERACTIONS_RECEIVED_FIELD_NUMBER: _ClassVar[int]
    DROPS_TOTAL_FIELD_NUMBER: _ClassVar[int]
    OUTBOX_QUEUE_DEPTH_FIELD_NUMBER: _ClassVar[int]
    OUTBOX_CAPACITY_FIELD_NUMBER: _ClassVar[int]
    JOIN_UNIX_SECONDS_FIELD_NUMBER: _ClassVar[int]
    handle: int
    name: str
    current_time: float
    pending_request_time: float
    lookahead: float
    regulating: bool
    constrained: bool
    published_object_classes: _containers.RepeatedScalarFieldContainer[int]
    subscribed_object_classes: _containers.RepeatedScalarFieldContainer[int]
    published_interaction_classes: _containers.RepeatedScalarFieldContainer[int]
    subscribed_interaction_classes: _containers.RepeatedScalarFieldContainer[int]
    updates_sent: int
    interactions_sent: int
    reflections_received: int
    interactions_received: int
    drops_total: int
    outbox_queue_depth: int
    outbox_capacity: int
    join_unix_seconds: int
    def __init__(self, handle: _Optional[int] = ..., name: _Optional[str] = ..., current_time: _Optional[float] = ..., pending_request_time: _Optional[float] = ..., lookahead: _Optional[float] = ..., regulating: _Optional[bool] = ..., constrained: _Optional[bool] = ..., published_object_classes: _Optional[_Iterable[int]] = ..., subscribed_object_classes: _Optional[_Iterable[int]] = ..., published_interaction_classes: _Optional[_Iterable[int]] = ..., subscribed_interaction_classes: _Optional[_Iterable[int]] = ..., updates_sent: _Optional[int] = ..., interactions_sent: _Optional[int] = ..., reflections_received: _Optional[int] = ..., interactions_received: _Optional[int] = ..., drops_total: _Optional[int] = ..., outbox_queue_depth: _Optional[int] = ..., outbox_capacity: _Optional[int] = ..., join_unix_seconds: _Optional[int] = ...) -> None: ...

class TimeSnapshot(_message.Message):
    __slots__ = ("lbts", "regulating_handles", "constrained_handles", "pending_grants")
    LBTS_FIELD_NUMBER: _ClassVar[int]
    REGULATING_HANDLES_FIELD_NUMBER: _ClassVar[int]
    CONSTRAINED_HANDLES_FIELD_NUMBER: _ClassVar[int]
    PENDING_GRANTS_FIELD_NUMBER: _ClassVar[int]
    lbts: float
    regulating_handles: _containers.RepeatedScalarFieldContainer[int]
    constrained_handles: _containers.RepeatedScalarFieldContainer[int]
    pending_grants: _containers.RepeatedCompositeFieldContainer[PendingGrant]
    def __init__(self, lbts: _Optional[float] = ..., regulating_handles: _Optional[_Iterable[int]] = ..., constrained_handles: _Optional[_Iterable[int]] = ..., pending_grants: _Optional[_Iterable[_Union[PendingGrant, _Mapping]]] = ...) -> None: ...

class PendingGrant(_message.Message):
    __slots__ = ("federate_handle", "requested_time")
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_TIME_FIELD_NUMBER: _ClassVar[int]
    federate_handle: int
    requested_time: float
    def __init__(self, federate_handle: _Optional[int] = ..., requested_time: _Optional[float] = ...) -> None: ...

class SyncPointSnapshot(_message.Message):
    __slots__ = ("label", "state", "required_handles", "achieved_handles")
    LABEL_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_HANDLES_FIELD_NUMBER: _ClassVar[int]
    ACHIEVED_HANDLES_FIELD_NUMBER: _ClassVar[int]
    label: str
    state: SyncPointState
    required_handles: _containers.RepeatedScalarFieldContainer[int]
    achieved_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, label: _Optional[str] = ..., state: _Optional[_Union[SyncPointState, str]] = ..., required_handles: _Optional[_Iterable[int]] = ..., achieved_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class TailEventsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "event_class_filter", "federate_handle_filter", "max_batch_events", "max_batch_latency_ms")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    EVENT_CLASS_FILTER_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FILTER_FIELD_NUMBER: _ClassVar[int]
    MAX_BATCH_EVENTS_FIELD_NUMBER: _ClassVar[int]
    MAX_BATCH_LATENCY_MS_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    event_class_filter: str
    federate_handle_filter: _containers.RepeatedScalarFieldContainer[int]
    max_batch_events: int
    max_batch_latency_ms: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., event_class_filter: _Optional[str] = ..., federate_handle_filter: _Optional[_Iterable[int]] = ..., max_batch_events: _Optional[int] = ..., max_batch_latency_ms: _Optional[int] = ...) -> None: ...

class TailedEvent(_message.Message):
    __slots__ = ("seq", "unix_nanos", "payload", "event_class", "federate_handle")
    SEQ_FIELD_NUMBER: _ClassVar[int]
    UNIX_NANOS_FIELD_NUMBER: _ClassVar[int]
    PAYLOAD_FIELD_NUMBER: _ClassVar[int]
    EVENT_CLASS_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    seq: int
    unix_nanos: int
    payload: bytes
    event_class: str
    federate_handle: int
    def __init__(self, seq: _Optional[int] = ..., unix_nanos: _Optional[int] = ..., payload: _Optional[bytes] = ..., event_class: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...

class TailEventsResponse(_message.Message):
    __slots__ = ("events", "overflow_skipped")
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    OVERFLOW_SKIPPED_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[TailedEvent]
    overflow_skipped: int
    def __init__(self, events: _Optional[_Iterable[_Union[TailedEvent, _Mapping]]] = ..., overflow_skipped: _Optional[int] = ...) -> None: ...
