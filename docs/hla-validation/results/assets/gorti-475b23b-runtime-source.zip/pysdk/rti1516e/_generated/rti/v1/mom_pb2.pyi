from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class QueryFederationAttributesRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ...) -> None: ...

class QueryFederationAttributesResponse(_message.Message):
    __slots__ = ("federation_name", "federate_handles", "fom_module_names")
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    FOM_MODULE_NAMES_FIELD_NUMBER: _ClassVar[int]
    federation_name: str
    federate_handles: _containers.RepeatedScalarFieldContainer[int]
    fom_module_names: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, federation_name: _Optional[str] = ..., federate_handles: _Optional[_Iterable[int]] = ..., fom_module_names: _Optional[_Iterable[str]] = ...) -> None: ...

class QueryFederateAttributesRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...

class QueryFederateAttributesResponse(_message.Message):
    __slots__ = ("found", "federate_handle", "federate_name", "federate_type", "time_regulating", "time_constrained", "logical_time", "lookahead", "interactions_sent", "interactions_received", "updates_sent", "reflections_received")
    FOUND_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    TIME_REGULATING_FIELD_NUMBER: _ClassVar[int]
    TIME_CONSTRAINED_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    LOOKAHEAD_FIELD_NUMBER: _ClassVar[int]
    INTERACTIONS_SENT_FIELD_NUMBER: _ClassVar[int]
    INTERACTIONS_RECEIVED_FIELD_NUMBER: _ClassVar[int]
    UPDATES_SENT_FIELD_NUMBER: _ClassVar[int]
    REFLECTIONS_RECEIVED_FIELD_NUMBER: _ClassVar[int]
    found: bool
    federate_handle: int
    federate_name: str
    federate_type: str
    time_regulating: bool
    time_constrained: bool
    logical_time: _common_pb2.LogicalTime
    lookahead: _common_pb2.LogicalTime
    interactions_sent: int
    interactions_received: int
    updates_sent: int
    reflections_received: int
    def __init__(self, found: _Optional[bool] = ..., federate_handle: _Optional[int] = ..., federate_name: _Optional[str] = ..., federate_type: _Optional[str] = ..., time_regulating: _Optional[bool] = ..., time_constrained: _Optional[bool] = ..., logical_time: _Optional[_Union[_common_pb2.LogicalTime, _Mapping]] = ..., lookahead: _Optional[_Union[_common_pb2.LogicalTime, _Mapping]] = ..., interactions_sent: _Optional[int] = ..., interactions_received: _Optional[int] = ..., updates_sent: _Optional[int] = ..., reflections_received: _Optional[int] = ...) -> None: ...

class EnumerateMomInstancesRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ...) -> None: ...

class MomInstance(_message.Message):
    __slots__ = ("class_name", "federate_handle", "instance_name")
    CLASS_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    INSTANCE_NAME_FIELD_NUMBER: _ClassVar[int]
    class_name: str
    federate_handle: int
    instance_name: str
    def __init__(self, class_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., instance_name: _Optional[str] = ...) -> None: ...

class EnumerateMomInstancesResponse(_message.Message):
    __slots__ = ("instances",)
    INSTANCES_FIELD_NUMBER: _ClassVar[int]
    instances: _containers.RepeatedCompositeFieldContainer[MomInstance]
    def __init__(self, instances: _Optional[_Iterable[_Union[MomInstance, _Mapping]]] = ...) -> None: ...

class MOMFederateRecord(_message.Message):
    __slots__ = ("handle", "name", "federate_type", "time_regulating", "time_constrained", "lookahead", "logical_time", "interactions_sent", "interactions_received", "updates_sent", "reflections_received")
    HANDLE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    TIME_REGULATING_FIELD_NUMBER: _ClassVar[int]
    TIME_CONSTRAINED_FIELD_NUMBER: _ClassVar[int]
    LOOKAHEAD_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    INTERACTIONS_SENT_FIELD_NUMBER: _ClassVar[int]
    INTERACTIONS_RECEIVED_FIELD_NUMBER: _ClassVar[int]
    UPDATES_SENT_FIELD_NUMBER: _ClassVar[int]
    REFLECTIONS_RECEIVED_FIELD_NUMBER: _ClassVar[int]
    handle: int
    name: str
    federate_type: str
    time_regulating: bool
    time_constrained: bool
    lookahead: float
    logical_time: float
    interactions_sent: int
    interactions_received: int
    updates_sent: int
    reflections_received: int
    def __init__(self, handle: _Optional[int] = ..., name: _Optional[str] = ..., federate_type: _Optional[str] = ..., time_regulating: _Optional[bool] = ..., time_constrained: _Optional[bool] = ..., lookahead: _Optional[float] = ..., logical_time: _Optional[float] = ..., interactions_sent: _Optional[int] = ..., interactions_received: _Optional[int] = ..., updates_sent: _Optional[int] = ..., reflections_received: _Optional[int] = ...) -> None: ...

class MOMFederationRecord(_message.Message):
    __slots__ = ("name", "federate_handles", "fom_module_names")
    NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    FOM_MODULE_NAMES_FIELD_NUMBER: _ClassVar[int]
    name: str
    federate_handles: _containers.RepeatedScalarFieldContainer[int]
    fom_module_names: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, name: _Optional[str] = ..., federate_handles: _Optional[_Iterable[int]] = ..., fom_module_names: _Optional[_Iterable[str]] = ...) -> None: ...

class MOMManagerState(_message.Message):
    __slots__ = ("federation", "federates")
    FEDERATION_FIELD_NUMBER: _ClassVar[int]
    FEDERATES_FIELD_NUMBER: _ClassVar[int]
    federation: MOMFederationRecord
    federates: _containers.RepeatedCompositeFieldContainer[MOMFederateRecord]
    def __init__(self, federation: _Optional[_Union[MOMFederationRecord, _Mapping]] = ..., federates: _Optional[_Iterable[_Union[MOMFederateRecord, _Mapping]]] = ...) -> None: ...
