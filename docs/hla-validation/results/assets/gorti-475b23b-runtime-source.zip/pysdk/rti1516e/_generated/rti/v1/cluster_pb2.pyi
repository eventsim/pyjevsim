from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ListClusterNodesRequest(_message.Message):
    __slots__ = ("wire_version",)
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ...) -> None: ...

class ListClusterNodesResponse(_message.Message):
    __slots__ = ("nodes",)
    NODES_FIELD_NUMBER: _ClassVar[int]
    nodes: _containers.RepeatedCompositeFieldContainer[ClusterNode]
    def __init__(self, nodes: _Optional[_Iterable[_Union[ClusterNode, _Mapping]]] = ...) -> None: ...

class ClusterNode(_message.Message):
    __slots__ = ("node_id", "address", "is_self")
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    IS_SELF_FIELD_NUMBER: _ClassVar[int]
    node_id: str
    address: str
    is_self: bool
    def __init__(self, node_id: _Optional[str] = ..., address: _Optional[str] = ..., is_self: _Optional[bool] = ...) -> None: ...

class LookupFederationHostRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ...) -> None: ...

class LookupFederationHostResponse(_message.Message):
    __slots__ = ("status", "host_address", "host_node_id")
    class Status(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        STATUS_UNSPECIFIED: _ClassVar[LookupFederationHostResponse.Status]
        NOT_FOUND: _ClassVar[LookupFederationHostResponse.Status]
        CURRENT: _ClassVar[LookupFederationHostResponse.Status]
        REDIRECT: _ClassVar[LookupFederationHostResponse.Status]
    STATUS_UNSPECIFIED: LookupFederationHostResponse.Status
    NOT_FOUND: LookupFederationHostResponse.Status
    CURRENT: LookupFederationHostResponse.Status
    REDIRECT: LookupFederationHostResponse.Status
    STATUS_FIELD_NUMBER: _ClassVar[int]
    HOST_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    HOST_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    status: LookupFederationHostResponse.Status
    host_address: str
    host_node_id: str
    def __init__(self, status: _Optional[_Union[LookupFederationHostResponse.Status, str]] = ..., host_address: _Optional[str] = ..., host_node_id: _Optional[str] = ...) -> None: ...

class ReportNodeHealthRequest(_message.Message):
    __slots__ = ("wire_version", "from_node_id")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FROM_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    from_node_id: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., from_node_id: _Optional[str] = ...) -> None: ...

class NotifyAssignmentRequest(_message.Message):
    __slots__ = ("wire_version", "from_node_id", "federation_name", "expected_federation_generation", "host_node_id", "host_address")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FROM_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_FEDERATION_GENERATION_FIELD_NUMBER: _ClassVar[int]
    HOST_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    HOST_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    from_node_id: str
    federation_name: str
    expected_federation_generation: int
    host_node_id: str
    host_address: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., from_node_id: _Optional[str] = ..., federation_name: _Optional[str] = ..., expected_federation_generation: _Optional[int] = ..., host_node_id: _Optional[str] = ..., host_address: _Optional[str] = ...) -> None: ...
