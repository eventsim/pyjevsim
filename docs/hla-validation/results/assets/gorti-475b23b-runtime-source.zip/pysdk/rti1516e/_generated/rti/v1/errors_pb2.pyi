from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ErrorCode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ERROR_CODE_UNSPECIFIED: _ClassVar[ErrorCode]
    ERR_FED_NOT_FOUND: _ClassVar[ErrorCode]
    ERR_FED_ALREADY_EXISTS: _ClassVar[ErrorCode]
    ERR_FED_NOT_JOINED: _ClassVar[ErrorCode]
    ERR_FED_ALREADY_JOINED: _ClassVar[ErrorCode]
    ERR_FED_HAS_FEDERATES_JOINED: _ClassVar[ErrorCode]
    ERR_FED_HALTED: _ClassVar[ErrorCode]
    ERR_FED_INVALID_NAME: _ClassVar[ErrorCode]
    ERR_FOM_VALIDATION_FAILED: _ClassVar[ErrorCode]
    ERR_FOM_MIM_REDEFINITION: _ClassVar[ErrorCode]
    ERR_OBJ_NOT_FOUND: _ClassVar[ErrorCode]
    ERR_OBJ_CLASS_NOT_PUBLISHED: _ClassVar[ErrorCode]
    ERR_OBJ_ATTR_NOT_OWNED: _ClassVar[ErrorCode]
    ERR_OBJ_HANDLE_INVALID: _ClassVar[ErrorCode]
    ERR_OBJ_INTERACTION_NOT_PUBLISHED: _ClassVar[ErrorCode]
    ERR_OBJ_CLASS_NOT_FOUND: _ClassVar[ErrorCode]
    ERR_OBJ_ATTR_NOT_FOUND: _ClassVar[ErrorCode]
    ERR_TIME_NOT_REGULATING: _ClassVar[ErrorCode]
    ERR_TIME_NOT_CONSTRAINED: _ClassVar[ErrorCode]
    ERR_TIME_INVALID_LOOKAHEAD: _ClassVar[ErrorCode]
    ERR_TIME_REQUEST_IN_PAST: _ClassVar[ErrorCode]
    ERR_TIME_ALREADY_REGULATING: _ClassVar[ErrorCode]
    ERR_TIME_ALREADY_CONSTRAINED: _ClassVar[ErrorCode]
    ERR_ENC_INSUFFICIENT_BYTES: _ClassVar[ErrorCode]
    ERR_ENC_TYPE_MISMATCH: _ClassVar[ErrorCode]
    ERR_ENC_PADDING_VIOLATION: _ClassVar[ErrorCode]
    ERR_WIRE_VERSION_MISMATCH: _ClassVar[ErrorCode]
    ERR_WIRE_MALFORMED_MESSAGE: _ClassVar[ErrorCode]
ERROR_CODE_UNSPECIFIED: ErrorCode
ERR_FED_NOT_FOUND: ErrorCode
ERR_FED_ALREADY_EXISTS: ErrorCode
ERR_FED_NOT_JOINED: ErrorCode
ERR_FED_ALREADY_JOINED: ErrorCode
ERR_FED_HAS_FEDERATES_JOINED: ErrorCode
ERR_FED_HALTED: ErrorCode
ERR_FED_INVALID_NAME: ErrorCode
ERR_FOM_VALIDATION_FAILED: ErrorCode
ERR_FOM_MIM_REDEFINITION: ErrorCode
ERR_OBJ_NOT_FOUND: ErrorCode
ERR_OBJ_CLASS_NOT_PUBLISHED: ErrorCode
ERR_OBJ_ATTR_NOT_OWNED: ErrorCode
ERR_OBJ_HANDLE_INVALID: ErrorCode
ERR_OBJ_INTERACTION_NOT_PUBLISHED: ErrorCode
ERR_OBJ_CLASS_NOT_FOUND: ErrorCode
ERR_OBJ_ATTR_NOT_FOUND: ErrorCode
ERR_TIME_NOT_REGULATING: ErrorCode
ERR_TIME_NOT_CONSTRAINED: ErrorCode
ERR_TIME_INVALID_LOOKAHEAD: ErrorCode
ERR_TIME_REQUEST_IN_PAST: ErrorCode
ERR_TIME_ALREADY_REGULATING: ErrorCode
ERR_TIME_ALREADY_CONSTRAINED: ErrorCode
ERR_ENC_INSUFFICIENT_BYTES: ErrorCode
ERR_ENC_TYPE_MISMATCH: ErrorCode
ERR_ENC_PADDING_VIOLATION: ErrorCode
ERR_WIRE_VERSION_MISMATCH: ErrorCode
ERR_WIRE_MALFORMED_MESSAGE: ErrorCode

class ErrorInfo(_message.Message):
    __slots__ = ("code", "message", "fom_code", "line")
    CODE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    FOM_CODE_FIELD_NUMBER: _ClassVar[int]
    LINE_FIELD_NUMBER: _ClassVar[int]
    code: ErrorCode
    message: str
    fom_code: str
    line: int
    def __init__(self, code: _Optional[_Union[ErrorCode, str]] = ..., message: _Optional[str] = ..., fom_code: _Optional[str] = ..., line: _Optional[int] = ...) -> None: ...
