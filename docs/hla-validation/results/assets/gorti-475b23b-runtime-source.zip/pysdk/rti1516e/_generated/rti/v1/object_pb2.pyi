from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RetractRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "message_retraction_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_RETRACTION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    message_retraction_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., message_retraction_handle: _Optional[int] = ...) -> None: ...

class RegisterObjectRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_class_handle", "object_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_class_handle: int
    object_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., object_name: _Optional[str] = ...) -> None: ...

class RegisterObjectResponse(_message.Message):
    __slots__ = ("object_handle", "object_name")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    object_name: str
    def __init__(self, object_handle: _Optional[int] = ..., object_name: _Optional[str] = ...) -> None: ...

class UpdateAttributeValuesRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attributes", "logical_time", "message_retraction_handle")
    class AttributesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: bytes
        def __init__(self, key: _Optional[int] = ..., value: _Optional[bytes] = ...) -> None: ...
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_RETRACTION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attributes: _containers.ScalarMap[int, bytes]
    logical_time: float
    message_retraction_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attributes: _Optional[_Mapping[int, bytes]] = ..., logical_time: _Optional[float] = ..., message_retraction_handle: _Optional[int] = ...) -> None: ...

class SendInteractionRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "interaction_class_handle", "parameters", "logical_time", "message_retraction_handle")
    class ParametersEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: bytes
        def __init__(self, key: _Optional[int] = ..., value: _Optional[bytes] = ...) -> None: ...
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_RETRACTION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    interaction_class_handle: int
    parameters: _containers.ScalarMap[int, bytes]
    logical_time: float
    message_retraction_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., interaction_class_handle: _Optional[int] = ..., parameters: _Optional[_Mapping[int, bytes]] = ..., logical_time: _Optional[float] = ..., message_retraction_handle: _Optional[int] = ...) -> None: ...

class DeleteObjectInstanceRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "logical_time", "user_supplied_tag")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    USER_SUPPLIED_TAG_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    logical_time: float
    user_supplied_tag: bytes
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., logical_time: _Optional[float] = ..., user_supplied_tag: _Optional[bytes] = ...) -> None: ...

class LocalDeleteObjectInstanceRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ...) -> None: ...

class RequestAttributeValueUpdateRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attribute_handles", "user_supplied_tag")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    USER_SUPPLIED_TAG_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    user_supplied_tag: bytes
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ..., user_supplied_tag: _Optional[bytes] = ...) -> None: ...

class RequestClassAttributeValueUpdateRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_class_handle", "attribute_handles", "user_supplied_tag")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    USER_SUPPLIED_TAG_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_class_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    user_supplied_tag: bytes
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ..., user_supplied_tag: _Optional[bytes] = ...) -> None: ...

class ChangeAttributeTransportRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attribute_handles", "transport_type")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TYPE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    transport_type: _common_pb2.TransportationType
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ..., transport_type: _Optional[_Union[_common_pb2.TransportationType, str]] = ...) -> None: ...

class ChangeInteractionTransportRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "interaction_class_handle", "transport_type")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TYPE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    interaction_class_handle: int
    transport_type: _common_pb2.TransportationType
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., interaction_class_handle: _Optional[int] = ..., transport_type: _Optional[_Union[_common_pb2.TransportationType, str]] = ...) -> None: ...

class ReserveObjectInstanceNameRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_name: _Optional[str] = ...) -> None: ...

class ReleaseObjectInstanceNameRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_name: _Optional[str] = ...) -> None: ...

class ReserveMultipleObjectInstanceNamesRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_names")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_NAMES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_names: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_names: _Optional[_Iterable[str]] = ...) -> None: ...
