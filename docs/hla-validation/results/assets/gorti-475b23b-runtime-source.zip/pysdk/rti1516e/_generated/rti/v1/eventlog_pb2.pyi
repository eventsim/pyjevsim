from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Event(_message.Message):
    __slots__ = ("seq", "wall_ns", "fed_joined", "fed_resigned", "obj_registered", "obj_deleted", "attr_updated", "inter_sent", "time_requested", "time_granted", "halted")
    SEQ_FIELD_NUMBER: _ClassVar[int]
    WALL_NS_FIELD_NUMBER: _ClassVar[int]
    FED_JOINED_FIELD_NUMBER: _ClassVar[int]
    FED_RESIGNED_FIELD_NUMBER: _ClassVar[int]
    OBJ_REGISTERED_FIELD_NUMBER: _ClassVar[int]
    OBJ_DELETED_FIELD_NUMBER: _ClassVar[int]
    ATTR_UPDATED_FIELD_NUMBER: _ClassVar[int]
    INTER_SENT_FIELD_NUMBER: _ClassVar[int]
    TIME_REQUESTED_FIELD_NUMBER: _ClassVar[int]
    TIME_GRANTED_FIELD_NUMBER: _ClassVar[int]
    HALTED_FIELD_NUMBER: _ClassVar[int]
    seq: int
    wall_ns: int
    fed_joined: FederateJoined
    fed_resigned: FederateResigned
    obj_registered: ObjectRegistered
    obj_deleted: ObjectDeleted
    attr_updated: AttributeUpdated
    inter_sent: InteractionSent
    time_requested: TimeAdvanceRequested
    time_granted: TimeAdvanceGranted
    halted: EventFederationHalted
    def __init__(self, seq: _Optional[int] = ..., wall_ns: _Optional[int] = ..., fed_joined: _Optional[_Union[FederateJoined, _Mapping]] = ..., fed_resigned: _Optional[_Union[FederateResigned, _Mapping]] = ..., obj_registered: _Optional[_Union[ObjectRegistered, _Mapping]] = ..., obj_deleted: _Optional[_Union[ObjectDeleted, _Mapping]] = ..., attr_updated: _Optional[_Union[AttributeUpdated, _Mapping]] = ..., inter_sent: _Optional[_Union[InteractionSent, _Mapping]] = ..., time_requested: _Optional[_Union[TimeAdvanceRequested, _Mapping]] = ..., time_granted: _Optional[_Union[TimeAdvanceGranted, _Mapping]] = ..., halted: _Optional[_Union[EventFederationHalted, _Mapping]] = ...) -> None: ...

class FederateJoined(_message.Message):
    __slots__ = ("federate_handle", "federate_name")
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_NAME_FIELD_NUMBER: _ClassVar[int]
    federate_handle: int
    federate_name: str
    def __init__(self, federate_handle: _Optional[int] = ..., federate_name: _Optional[str] = ...) -> None: ...

class FederateResigned(_message.Message):
    __slots__ = ("federate_handle", "action")
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    federate_handle: int
    action: _common_pb2.ResignAction
    def __init__(self, federate_handle: _Optional[int] = ..., action: _Optional[_Union[_common_pb2.ResignAction, str]] = ...) -> None: ...

class ObjectRegistered(_message.Message):
    __slots__ = ("object_handle", "object_class_handle", "owner_federate_handle", "object_name")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OWNER_FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    object_class_handle: int
    owner_federate_handle: int
    object_name: str
    def __init__(self, object_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., owner_federate_handle: _Optional[int] = ..., object_name: _Optional[str] = ...) -> None: ...

class ObjectDeleted(_message.Message):
    __slots__ = ("object_handle", "logical_time")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    logical_time: float
    def __init__(self, object_handle: _Optional[int] = ..., logical_time: _Optional[float] = ...) -> None: ...

class AttributeUpdated(_message.Message):
    __slots__ = ("object_handle", "producer_federate_handle", "attributes", "logical_time")
    class AttributesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: bytes
        def __init__(self, key: _Optional[int] = ..., value: _Optional[bytes] = ...) -> None: ...
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    PRODUCER_FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    producer_federate_handle: int
    attributes: _containers.ScalarMap[int, bytes]
    logical_time: float
    def __init__(self, object_handle: _Optional[int] = ..., producer_federate_handle: _Optional[int] = ..., attributes: _Optional[_Mapping[int, bytes]] = ..., logical_time: _Optional[float] = ...) -> None: ...

class InteractionSent(_message.Message):
    __slots__ = ("interaction_class_handle", "producer_federate_handle", "parameters", "logical_time")
    class ParametersEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: bytes
        def __init__(self, key: _Optional[int] = ..., value: _Optional[bytes] = ...) -> None: ...
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    PRODUCER_FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    interaction_class_handle: int
    producer_federate_handle: int
    parameters: _containers.ScalarMap[int, bytes]
    logical_time: float
    def __init__(self, interaction_class_handle: _Optional[int] = ..., producer_federate_handle: _Optional[int] = ..., parameters: _Optional[_Mapping[int, bytes]] = ..., logical_time: _Optional[float] = ...) -> None: ...

class TimeAdvanceRequested(_message.Message):
    __slots__ = ("federate_handle", "logical_time")
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    federate_handle: int
    logical_time: float
    def __init__(self, federate_handle: _Optional[int] = ..., logical_time: _Optional[float] = ...) -> None: ...

class TimeAdvanceGranted(_message.Message):
    __slots__ = ("federate_handle", "logical_time")
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    federate_handle: int
    logical_time: float
    def __init__(self, federate_handle: _Optional[int] = ..., logical_time: _Optional[float] = ...) -> None: ...

class EventFederationHalted(_message.Message):
    __slots__ = ("cause",)
    CAUSE_FIELD_NUMBER: _ClassVar[int]
    cause: str
    def __init__(self, cause: _Optional[str] = ...) -> None: ...
