from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SyncPointSnapshotState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SYNC_POINT_SNAPSHOT_STATE_UNSPECIFIED: _ClassVar[SyncPointSnapshotState]
    SYNC_POINT_SNAPSHOT_STATE_ANNOUNCED: _ClassVar[SyncPointSnapshotState]
    SYNC_POINT_SNAPSHOT_STATE_ACHIEVED: _ClassVar[SyncPointSnapshotState]
SYNC_POINT_SNAPSHOT_STATE_UNSPECIFIED: SyncPointSnapshotState
SYNC_POINT_SNAPSHOT_STATE_ANNOUNCED: SyncPointSnapshotState
SYNC_POINT_SNAPSHOT_STATE_ACHIEVED: SyncPointSnapshotState

class RegisterSyncPointRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "label", "tag", "required_federates")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FEDERATES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    label: str
    tag: bytes
    required_federates: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., label: _Optional[str] = ..., tag: _Optional[bytes] = ..., required_federates: _Optional[_Iterable[int]] = ...) -> None: ...

class AchieveSyncPointRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "label", "successfully")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    SUCCESSFULLY_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    label: str
    successfully: bool
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., label: _Optional[str] = ..., successfully: _Optional[bool] = ...) -> None: ...

class SyncPointStateEntry(_message.Message):
    __slots__ = ("label", "tag", "state", "required", "achieved", "dynamic")
    LABEL_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    ACHIEVED_FIELD_NUMBER: _ClassVar[int]
    DYNAMIC_FIELD_NUMBER: _ClassVar[int]
    label: str
    tag: bytes
    state: SyncPointSnapshotState
    required: _containers.RepeatedScalarFieldContainer[int]
    achieved: _containers.RepeatedScalarFieldContainer[int]
    dynamic: bool
    def __init__(self, label: _Optional[str] = ..., tag: _Optional[bytes] = ..., state: _Optional[_Union[SyncPointSnapshotState, str]] = ..., required: _Optional[_Iterable[int]] = ..., achieved: _Optional[_Iterable[int]] = ..., dynamic: _Optional[bool] = ...) -> None: ...

class SyncManagerState(_message.Message):
    __slots__ = ("points",)
    POINTS_FIELD_NUMBER: _ClassVar[int]
    points: _containers.RepeatedCompositeFieldContainer[SyncPointStateEntry]
    def __init__(self, points: _Optional[_Iterable[_Union[SyncPointStateEntry, _Mapping]]] = ...) -> None: ...
