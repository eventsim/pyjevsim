from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class UnconditionalDivestRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attribute_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class NegotiatedDivestRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attribute_handles", "tag", "two_phase")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    TWO_PHASE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    tag: bytes
    two_phase: bool
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ..., tag: _Optional[bytes] = ..., two_phase: _Optional[bool] = ...) -> None: ...

class ConfirmDivestitureRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attribute_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class AcquireRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attribute_handles", "tag", "if_available")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    IF_AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    tag: bytes
    if_available: bool
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ..., tag: _Optional[bytes] = ..., if_available: _Optional[bool] = ...) -> None: ...

class CancelDivestRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attribute_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class CancelAcquireRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attribute_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class DivestIfWantedRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attribute_handles")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class QueryOwnershipRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "object_handle", "attribute_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    object_handle: int
    attribute_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., object_handle: _Optional[int] = ..., attribute_handle: _Optional[int] = ...) -> None: ...

class QueryOwnershipResponse(_message.Message):
    __slots__ = ("owner_federate_handle", "owned")
    OWNER_FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OWNED_FIELD_NUMBER: _ClassVar[int]
    owner_federate_handle: int
    owned: bool
    def __init__(self, owner_federate_handle: _Optional[int] = ..., owned: _Optional[bool] = ...) -> None: ...

class IsOwnedRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "object_handle", "attribute_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    object_handle: int
    attribute_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., object_handle: _Optional[int] = ..., attribute_handle: _Optional[int] = ...) -> None: ...

class IsOwnedResponse(_message.Message):
    __slots__ = ("owned",)
    OWNED_FIELD_NUMBER: _ClassVar[int]
    owned: bool
    def __init__(self, owned: _Optional[bool] = ...) -> None: ...

class OwnershipRecordEntry(_message.Message):
    __slots__ = ("object_handle", "attribute_handle", "owner_federate")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OWNER_FEDERATE_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    attribute_handle: int
    owner_federate: int
    def __init__(self, object_handle: _Optional[int] = ..., attribute_handle: _Optional[int] = ..., owner_federate: _Optional[int] = ...) -> None: ...

class PendingDivestEntry(_message.Message):
    __slots__ = ("object_handle", "attribute_handle", "owner_federate", "tag")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OWNER_FEDERATE_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    attribute_handle: int
    owner_federate: int
    tag: bytes
    def __init__(self, object_handle: _Optional[int] = ..., attribute_handle: _Optional[int] = ..., owner_federate: _Optional[int] = ..., tag: _Optional[bytes] = ...) -> None: ...

class PendingAcquireEntry(_message.Message):
    __slots__ = ("object_handle", "attribute_handle", "acquirer_federate", "tag")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ACQUIRER_FEDERATE_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    attribute_handle: int
    acquirer_federate: int
    tag: bytes
    def __init__(self, object_handle: _Optional[int] = ..., attribute_handle: _Optional[int] = ..., acquirer_federate: _Optional[int] = ..., tag: _Optional[bytes] = ...) -> None: ...

class OwnershipManagerState(_message.Message):
    __slots__ = ("owners", "pending_divests", "pending_acquires")
    OWNERS_FIELD_NUMBER: _ClassVar[int]
    PENDING_DIVESTS_FIELD_NUMBER: _ClassVar[int]
    PENDING_ACQUIRES_FIELD_NUMBER: _ClassVar[int]
    owners: _containers.RepeatedCompositeFieldContainer[OwnershipRecordEntry]
    pending_divests: _containers.RepeatedCompositeFieldContainer[PendingDivestEntry]
    pending_acquires: _containers.RepeatedCompositeFieldContainer[PendingAcquireEntry]
    def __init__(self, owners: _Optional[_Iterable[_Union[OwnershipRecordEntry, _Mapping]]] = ..., pending_divests: _Optional[_Iterable[_Union[PendingDivestEntry, _Mapping]]] = ..., pending_acquires: _Optional[_Iterable[_Union[PendingAcquireEntry, _Mapping]]] = ...) -> None: ...
