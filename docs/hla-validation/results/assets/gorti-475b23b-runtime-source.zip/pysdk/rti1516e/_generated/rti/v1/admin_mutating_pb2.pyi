from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MutatingProbeRequest(_message.Message):
    __slots__ = ("wire_version",)
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ...) -> None: ...

class MutatingProbeResponse(_message.Message):
    __slots__ = ("rtid_version", "mutating_enabled")
    RTID_VERSION_FIELD_NUMBER: _ClassVar[int]
    MUTATING_ENABLED_FIELD_NUMBER: _ClassVar[int]
    rtid_version: str
    mutating_enabled: bool
    def __init__(self, rtid_version: _Optional[str] = ..., mutating_enabled: _Optional[bool] = ...) -> None: ...

class ForceResignRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...

class ForceResignResponse(_message.Message):
    __slots__ = ("already_resigned",)
    ALREADY_RESIGNED_FIELD_NUMBER: _ClassVar[int]
    already_resigned: bool
    def __init__(self, already_resigned: _Optional[bool] = ...) -> None: ...

class AdminDestroyFederationRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "expected_federation_generation", "evict_joined_federates")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_FEDERATION_GENERATION_FIELD_NUMBER: _ClassVar[int]
    EVICT_JOINED_FEDERATES_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    expected_federation_generation: int
    evict_joined_federates: bool
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., expected_federation_generation: _Optional[int] = ..., evict_joined_federates: _Optional[bool] = ...) -> None: ...

class AdminDestroyFederationResponse(_message.Message):
    __slots__ = ("evicted_handles",)
    EVICTED_HANDLES_FIELD_NUMBER: _ClassVar[int]
    evicted_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, evicted_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class PromoteFederationRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "expected_federation_generation", "target_node_id")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_FEDERATION_GENERATION_FIELD_NUMBER: _ClassVar[int]
    TARGET_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    expected_federation_generation: int
    target_node_id: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., expected_federation_generation: _Optional[int] = ..., target_node_id: _Optional[str] = ...) -> None: ...

class PromoteFederationResponse(_message.Message):
    __slots__ = ("prior_node_id",)
    PRIOR_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    prior_node_id: str
    def __init__(self, prior_node_id: _Optional[str] = ...) -> None: ...
