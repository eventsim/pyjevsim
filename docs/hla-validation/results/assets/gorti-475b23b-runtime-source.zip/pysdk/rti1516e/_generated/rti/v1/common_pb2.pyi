from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class WireVersion(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    WIRE_VERSION_UNSPECIFIED: _ClassVar[WireVersion]
    WIRE_VERSION_V1: _ClassVar[WireVersion]

class Mode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MODE_UNSPECIFIED: _ClassVar[Mode]
    MODE_VERBOSE: _ClassVar[Mode]
    MODE_BEST_EFFORT: _ClassVar[Mode]

class ResignAction(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RESIGN_ACTION_UNSPECIFIED: _ClassVar[ResignAction]
    RESIGN_ACTION_UNCONDITIONALLY_DIVEST_ATTRIBUTES: _ClassVar[ResignAction]
    RESIGN_ACTION_DELETE_THEN_DIVEST: _ClassVar[ResignAction]
    RESIGN_ACTION_CANCEL_THEN_DELETE: _ClassVar[ResignAction]
    RESIGN_ACTION_CANCEL_PENDING_OWNERSHIP: _ClassVar[ResignAction]
    RESIGN_ACTION_NO_ACTION: _ClassVar[ResignAction]
    RESIGN_ACTION_DELETE_OBJECTS: _ClassVar[ResignAction]

class TransportationType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TRANSPORTATION_TYPE_UNSPECIFIED: _ClassVar[TransportationType]
    TRANSPORTATION_TYPE_RELIABLE: _ClassVar[TransportationType]
    TRANSPORTATION_TYPE_BEST_EFFORT: _ClassVar[TransportationType]
WIRE_VERSION_UNSPECIFIED: WireVersion
WIRE_VERSION_V1: WireVersion
MODE_UNSPECIFIED: Mode
MODE_VERBOSE: Mode
MODE_BEST_EFFORT: Mode
RESIGN_ACTION_UNSPECIFIED: ResignAction
RESIGN_ACTION_UNCONDITIONALLY_DIVEST_ATTRIBUTES: ResignAction
RESIGN_ACTION_DELETE_THEN_DIVEST: ResignAction
RESIGN_ACTION_CANCEL_THEN_DELETE: ResignAction
RESIGN_ACTION_CANCEL_PENDING_OWNERSHIP: ResignAction
RESIGN_ACTION_NO_ACTION: ResignAction
RESIGN_ACTION_DELETE_OBJECTS: ResignAction
TRANSPORTATION_TYPE_UNSPECIFIED: TransportationType
TRANSPORTATION_TYPE_RELIABLE: TransportationType
TRANSPORTATION_TYPE_BEST_EFFORT: TransportationType

class Empty(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class LogicalTime(_message.Message):
    __slots__ = ("value",)
    VALUE_FIELD_NUMBER: _ClassVar[int]
    value: float
    def __init__(self, value: _Optional[float] = ...) -> None: ...

class FOMModule(_message.Message):
    __slots__ = ("path", "xml")
    PATH_FIELD_NUMBER: _ClassVar[int]
    XML_FIELD_NUMBER: _ClassVar[int]
    path: str
    xml: bytes
    def __init__(self, path: _Optional[str] = ..., xml: _Optional[bytes] = ...) -> None: ...
