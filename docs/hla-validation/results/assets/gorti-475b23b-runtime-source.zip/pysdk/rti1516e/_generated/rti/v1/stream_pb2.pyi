from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SyncPointFailureReason(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SYNC_POINT_FAILURE_REASON_UNSPECIFIED: _ClassVar[SyncPointFailureReason]
    SYNC_POINT_FAILURE_REASON_LABEL_NOT_UNIQUE: _ClassVar[SyncPointFailureReason]
    SYNC_POINT_FAILURE_REASON_SET_MEMBER_NOT_JOINED: _ClassVar[SyncPointFailureReason]
SYNC_POINT_FAILURE_REASON_UNSPECIFIED: SyncPointFailureReason
SYNC_POINT_FAILURE_REASON_LABEL_NOT_UNIQUE: SyncPointFailureReason
SYNC_POINT_FAILURE_REASON_SET_MEMBER_NOT_JOINED: SyncPointFailureReason

class EventsRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "expected_federation_generation")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_FEDERATION_GENERATION_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    expected_federation_generation: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., expected_federation_generation: _Optional[int] = ...) -> None: ...

class FederateEventBatch(_message.Message):
    __slots__ = ("events", "ready")
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    READY_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[FederateEvent]
    ready: bool
    def __init__(self, events: _Optional[_Iterable[_Union[FederateEvent, _Mapping]]] = ..., ready: _Optional[bool] = ...) -> None: ...

class FederateEvent(_message.Message):
    __slots__ = ("seq", "discover", "reflect", "remove", "receive", "grant", "provide_update", "sync_announced", "sync_synchronized", "sync_registration_succeeded", "sync_registration_failed", "ownership_assumption", "ownership_acquired", "ownership_divest_confirmed", "ownership_release_requested", "ownership_unavailable", "save_initiate", "save_completed", "save_failed", "restore_initiate", "restore_completed", "restore_failed", "restore_request_succeeded", "restore_request_failed", "restore_begun", "reservation_succeeded", "reservation_failed", "reservation_multi_succeeded", "reservation_multi_failed", "start_registration", "stop_registration", "turn_interactions_on", "turn_interactions_off", "attributes_in_scope", "attributes_out_of_scope", "retraction_requested", "halted")
    SEQ_FIELD_NUMBER: _ClassVar[int]
    DISCOVER_FIELD_NUMBER: _ClassVar[int]
    REFLECT_FIELD_NUMBER: _ClassVar[int]
    REMOVE_FIELD_NUMBER: _ClassVar[int]
    RECEIVE_FIELD_NUMBER: _ClassVar[int]
    GRANT_FIELD_NUMBER: _ClassVar[int]
    PROVIDE_UPDATE_FIELD_NUMBER: _ClassVar[int]
    SYNC_ANNOUNCED_FIELD_NUMBER: _ClassVar[int]
    SYNC_SYNCHRONIZED_FIELD_NUMBER: _ClassVar[int]
    SYNC_REGISTRATION_SUCCEEDED_FIELD_NUMBER: _ClassVar[int]
    SYNC_REGISTRATION_FAILED_FIELD_NUMBER: _ClassVar[int]
    OWNERSHIP_ASSUMPTION_FIELD_NUMBER: _ClassVar[int]
    OWNERSHIP_ACQUIRED_FIELD_NUMBER: _ClassVar[int]
    OWNERSHIP_DIVEST_CONFIRMED_FIELD_NUMBER: _ClassVar[int]
    OWNERSHIP_RELEASE_REQUESTED_FIELD_NUMBER: _ClassVar[int]
    OWNERSHIP_UNAVAILABLE_FIELD_NUMBER: _ClassVar[int]
    SAVE_INITIATE_FIELD_NUMBER: _ClassVar[int]
    SAVE_COMPLETED_FIELD_NUMBER: _ClassVar[int]
    SAVE_FAILED_FIELD_NUMBER: _ClassVar[int]
    RESTORE_INITIATE_FIELD_NUMBER: _ClassVar[int]
    RESTORE_COMPLETED_FIELD_NUMBER: _ClassVar[int]
    RESTORE_FAILED_FIELD_NUMBER: _ClassVar[int]
    RESTORE_REQUEST_SUCCEEDED_FIELD_NUMBER: _ClassVar[int]
    RESTORE_REQUEST_FAILED_FIELD_NUMBER: _ClassVar[int]
    RESTORE_BEGUN_FIELD_NUMBER: _ClassVar[int]
    RESERVATION_SUCCEEDED_FIELD_NUMBER: _ClassVar[int]
    RESERVATION_FAILED_FIELD_NUMBER: _ClassVar[int]
    RESERVATION_MULTI_SUCCEEDED_FIELD_NUMBER: _ClassVar[int]
    RESERVATION_MULTI_FAILED_FIELD_NUMBER: _ClassVar[int]
    START_REGISTRATION_FIELD_NUMBER: _ClassVar[int]
    STOP_REGISTRATION_FIELD_NUMBER: _ClassVar[int]
    TURN_INTERACTIONS_ON_FIELD_NUMBER: _ClassVar[int]
    TURN_INTERACTIONS_OFF_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTES_IN_SCOPE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTES_OUT_OF_SCOPE_FIELD_NUMBER: _ClassVar[int]
    RETRACTION_REQUESTED_FIELD_NUMBER: _ClassVar[int]
    HALTED_FIELD_NUMBER: _ClassVar[int]
    seq: int
    discover: DiscoverObjectInstance
    reflect: ReflectAttributeValues
    remove: RemoveObjectInstance
    receive: ReceiveInteraction
    grant: TimeAdvanceGrant
    provide_update: ProvideAttributeValueUpdate
    sync_announced: SynchronizationPointAnnounced
    sync_synchronized: FederationSynchronized
    sync_registration_succeeded: SyncRegistrationSucceeded
    sync_registration_failed: SyncRegistrationFailed
    ownership_assumption: RequestAttributeOwnershipAssumption
    ownership_acquired: AttributeOwnershipAcquisitionNotification
    ownership_divest_confirmed: RequestDivestitureConfirmation
    ownership_release_requested: RequestAttributeOwnershipRelease
    ownership_unavailable: AttributeOwnershipUnavailable
    save_initiate: InitiateFederateSave
    save_completed: FederationSaved
    save_failed: FederationNotSaved
    restore_initiate: InitiateFederateRestore
    restore_completed: FederationRestored
    restore_failed: FederationNotRestored
    restore_request_succeeded: RequestFederationRestoreSucceeded
    restore_request_failed: RequestFederationRestoreFailed
    restore_begun: FederationRestoreBegun
    reservation_succeeded: ObjectInstanceNameReservationSucceeded
    reservation_failed: ObjectInstanceNameReservationFailed
    reservation_multi_succeeded: MultipleObjectInstanceNameReservationSucceeded
    reservation_multi_failed: MultipleObjectInstanceNameReservationFailed
    start_registration: StartRegistrationForObjectClass
    stop_registration: StopRegistrationForObjectClass
    turn_interactions_on: TurnInteractionsOn
    turn_interactions_off: TurnInteractionsOff
    attributes_in_scope: AttributesInScope
    attributes_out_of_scope: AttributesOutOfScope
    retraction_requested: RequestRetraction
    halted: FederationHalted
    def __init__(self, seq: _Optional[int] = ..., discover: _Optional[_Union[DiscoverObjectInstance, _Mapping]] = ..., reflect: _Optional[_Union[ReflectAttributeValues, _Mapping]] = ..., remove: _Optional[_Union[RemoveObjectInstance, _Mapping]] = ..., receive: _Optional[_Union[ReceiveInteraction, _Mapping]] = ..., grant: _Optional[_Union[TimeAdvanceGrant, _Mapping]] = ..., provide_update: _Optional[_Union[ProvideAttributeValueUpdate, _Mapping]] = ..., sync_announced: _Optional[_Union[SynchronizationPointAnnounced, _Mapping]] = ..., sync_synchronized: _Optional[_Union[FederationSynchronized, _Mapping]] = ..., sync_registration_succeeded: _Optional[_Union[SyncRegistrationSucceeded, _Mapping]] = ..., sync_registration_failed: _Optional[_Union[SyncRegistrationFailed, _Mapping]] = ..., ownership_assumption: _Optional[_Union[RequestAttributeOwnershipAssumption, _Mapping]] = ..., ownership_acquired: _Optional[_Union[AttributeOwnershipAcquisitionNotification, _Mapping]] = ..., ownership_divest_confirmed: _Optional[_Union[RequestDivestitureConfirmation, _Mapping]] = ..., ownership_release_requested: _Optional[_Union[RequestAttributeOwnershipRelease, _Mapping]] = ..., ownership_unavailable: _Optional[_Union[AttributeOwnershipUnavailable, _Mapping]] = ..., save_initiate: _Optional[_Union[InitiateFederateSave, _Mapping]] = ..., save_completed: _Optional[_Union[FederationSaved, _Mapping]] = ..., save_failed: _Optional[_Union[FederationNotSaved, _Mapping]] = ..., restore_initiate: _Optional[_Union[InitiateFederateRestore, _Mapping]] = ..., restore_completed: _Optional[_Union[FederationRestored, _Mapping]] = ..., restore_failed: _Optional[_Union[FederationNotRestored, _Mapping]] = ..., restore_request_succeeded: _Optional[_Union[RequestFederationRestoreSucceeded, _Mapping]] = ..., restore_request_failed: _Optional[_Union[RequestFederationRestoreFailed, _Mapping]] = ..., restore_begun: _Optional[_Union[FederationRestoreBegun, _Mapping]] = ..., reservation_succeeded: _Optional[_Union[ObjectInstanceNameReservationSucceeded, _Mapping]] = ..., reservation_failed: _Optional[_Union[ObjectInstanceNameReservationFailed, _Mapping]] = ..., reservation_multi_succeeded: _Optional[_Union[MultipleObjectInstanceNameReservationSucceeded, _Mapping]] = ..., reservation_multi_failed: _Optional[_Union[MultipleObjectInstanceNameReservationFailed, _Mapping]] = ..., start_registration: _Optional[_Union[StartRegistrationForObjectClass, _Mapping]] = ..., stop_registration: _Optional[_Union[StopRegistrationForObjectClass, _Mapping]] = ..., turn_interactions_on: _Optional[_Union[TurnInteractionsOn, _Mapping]] = ..., turn_interactions_off: _Optional[_Union[TurnInteractionsOff, _Mapping]] = ..., attributes_in_scope: _Optional[_Union[AttributesInScope, _Mapping]] = ..., attributes_out_of_scope: _Optional[_Union[AttributesOutOfScope, _Mapping]] = ..., retraction_requested: _Optional[_Union[RequestRetraction, _Mapping]] = ..., halted: _Optional[_Union[FederationHalted, _Mapping]] = ...) -> None: ...

class DiscoverObjectInstance(_message.Message):
    __slots__ = ("object_handle", "object_class_handle", "object_name")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    object_class_handle: int
    object_name: str
    def __init__(self, object_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., object_name: _Optional[str] = ...) -> None: ...

class ReflectAttributeValues(_message.Message):
    __slots__ = ("object_handle", "object_class_handle", "attributes", "logical_time")
    class AttributesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: bytes
        def __init__(self, key: _Optional[int] = ..., value: _Optional[bytes] = ...) -> None: ...
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    object_class_handle: int
    attributes: _containers.ScalarMap[int, bytes]
    logical_time: float
    def __init__(self, object_handle: _Optional[int] = ..., object_class_handle: _Optional[int] = ..., attributes: _Optional[_Mapping[int, bytes]] = ..., logical_time: _Optional[float] = ...) -> None: ...

class RemoveObjectInstance(_message.Message):
    __slots__ = ("object_handle", "logical_time", "user_supplied_tag")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    USER_SUPPLIED_TAG_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    logical_time: float
    user_supplied_tag: bytes
    def __init__(self, object_handle: _Optional[int] = ..., logical_time: _Optional[float] = ..., user_supplied_tag: _Optional[bytes] = ...) -> None: ...

class ProvideAttributeValueUpdate(_message.Message):
    __slots__ = ("object_handle", "attribute_handles", "user_supplied_tag")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    USER_SUPPLIED_TAG_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    user_supplied_tag: bytes
    def __init__(self, object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ..., user_supplied_tag: _Optional[bytes] = ...) -> None: ...

class ReceiveInteraction(_message.Message):
    __slots__ = ("interaction_class_handle", "parameters", "logical_time")
    class ParametersEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: bytes
        def __init__(self, key: _Optional[int] = ..., value: _Optional[bytes] = ...) -> None: ...
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    interaction_class_handle: int
    parameters: _containers.ScalarMap[int, bytes]
    logical_time: float
    def __init__(self, interaction_class_handle: _Optional[int] = ..., parameters: _Optional[_Mapping[int, bytes]] = ..., logical_time: _Optional[float] = ...) -> None: ...

class TimeAdvanceGrant(_message.Message):
    __slots__ = ("logical_time",)
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    logical_time: float
    def __init__(self, logical_time: _Optional[float] = ...) -> None: ...

class FederationHalted(_message.Message):
    __slots__ = ("cause",)
    CAUSE_FIELD_NUMBER: _ClassVar[int]
    cause: str
    def __init__(self, cause: _Optional[str] = ...) -> None: ...

class SynchronizationPointAnnounced(_message.Message):
    __slots__ = ("label", "tag", "required_federates")
    LABEL_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FEDERATES_FIELD_NUMBER: _ClassVar[int]
    label: str
    tag: bytes
    required_federates: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, label: _Optional[str] = ..., tag: _Optional[bytes] = ..., required_federates: _Optional[_Iterable[int]] = ...) -> None: ...

class FederationSynchronized(_message.Message):
    __slots__ = ("label", "failed_to_sync")
    LABEL_FIELD_NUMBER: _ClassVar[int]
    FAILED_TO_SYNC_FIELD_NUMBER: _ClassVar[int]
    label: str
    failed_to_sync: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, label: _Optional[str] = ..., failed_to_sync: _Optional[_Iterable[int]] = ...) -> None: ...

class SyncRegistrationSucceeded(_message.Message):
    __slots__ = ("label",)
    LABEL_FIELD_NUMBER: _ClassVar[int]
    label: str
    def __init__(self, label: _Optional[str] = ...) -> None: ...

class SyncRegistrationFailed(_message.Message):
    __slots__ = ("label", "reason")
    LABEL_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    label: str
    reason: SyncPointFailureReason
    def __init__(self, label: _Optional[str] = ..., reason: _Optional[_Union[SyncPointFailureReason, str]] = ...) -> None: ...

class RequestAttributeOwnershipAssumption(_message.Message):
    __slots__ = ("object_handle", "attribute_handles", "divesting_federate", "tag")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    DIVESTING_FEDERATE_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    divesting_federate: int
    tag: bytes
    def __init__(self, object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ..., divesting_federate: _Optional[int] = ..., tag: _Optional[bytes] = ...) -> None: ...

class AttributeOwnershipAcquisitionNotification(_message.Message):
    __slots__ = ("object_handle", "attribute_handles", "owning_federate")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    OWNING_FEDERATE_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    owning_federate: int
    def __init__(self, object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ..., owning_federate: _Optional[int] = ...) -> None: ...

class RequestDivestitureConfirmation(_message.Message):
    __slots__ = ("object_handle", "attribute_handles")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class AttributeOwnershipUnavailable(_message.Message):
    __slots__ = ("object_handle", "attribute_handles")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class RequestAttributeOwnershipRelease(_message.Message):
    __slots__ = ("object_handle", "attribute_handles", "tag")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    tag: bytes
    def __init__(self, object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ..., tag: _Optional[bytes] = ...) -> None: ...

class InitiateFederateSave(_message.Message):
    __slots__ = ("label", "save_time")
    LABEL_FIELD_NUMBER: _ClassVar[int]
    SAVE_TIME_FIELD_NUMBER: _ClassVar[int]
    label: str
    save_time: float
    def __init__(self, label: _Optional[str] = ..., save_time: _Optional[float] = ...) -> None: ...

class FederationSaved(_message.Message):
    __slots__ = ("label",)
    LABEL_FIELD_NUMBER: _ClassVar[int]
    label: str
    def __init__(self, label: _Optional[str] = ...) -> None: ...

class FederationNotSaved(_message.Message):
    __slots__ = ("label",)
    LABEL_FIELD_NUMBER: _ClassVar[int]
    label: str
    def __init__(self, label: _Optional[str] = ...) -> None: ...

class InitiateFederateRestore(_message.Message):
    __slots__ = ("label", "federate_handle", "federate_name")
    LABEL_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_NAME_FIELD_NUMBER: _ClassVar[int]
    label: str
    federate_handle: int
    federate_name: str
    def __init__(self, label: _Optional[str] = ..., federate_handle: _Optional[int] = ..., federate_name: _Optional[str] = ...) -> None: ...

class RequestFederationRestoreSucceeded(_message.Message):
    __slots__ = ("label",)
    LABEL_FIELD_NUMBER: _ClassVar[int]
    label: str
    def __init__(self, label: _Optional[str] = ...) -> None: ...

class RequestFederationRestoreFailed(_message.Message):
    __slots__ = ("label", "reason")
    LABEL_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    label: str
    reason: str
    def __init__(self, label: _Optional[str] = ..., reason: _Optional[str] = ...) -> None: ...

class FederationRestoreBegun(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FederationRestored(_message.Message):
    __slots__ = ("label",)
    LABEL_FIELD_NUMBER: _ClassVar[int]
    label: str
    def __init__(self, label: _Optional[str] = ...) -> None: ...

class FederationNotRestored(_message.Message):
    __slots__ = ("label",)
    LABEL_FIELD_NUMBER: _ClassVar[int]
    label: str
    def __init__(self, label: _Optional[str] = ...) -> None: ...

class StartRegistrationForObjectClass(_message.Message):
    __slots__ = ("object_class_handle",)
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    object_class_handle: int
    def __init__(self, object_class_handle: _Optional[int] = ...) -> None: ...

class StopRegistrationForObjectClass(_message.Message):
    __slots__ = ("object_class_handle",)
    OBJECT_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    object_class_handle: int
    def __init__(self, object_class_handle: _Optional[int] = ...) -> None: ...

class TurnInteractionsOn(_message.Message):
    __slots__ = ("interaction_class_handle",)
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    interaction_class_handle: int
    def __init__(self, interaction_class_handle: _Optional[int] = ...) -> None: ...

class TurnInteractionsOff(_message.Message):
    __slots__ = ("interaction_class_handle",)
    INTERACTION_CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    interaction_class_handle: int
    def __init__(self, interaction_class_handle: _Optional[int] = ...) -> None: ...

class RequestRetraction(_message.Message):
    __slots__ = ("sender_federate", "message_retraction_handle")
    SENDER_FEDERATE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_RETRACTION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    sender_federate: int
    message_retraction_handle: int
    def __init__(self, sender_federate: _Optional[int] = ..., message_retraction_handle: _Optional[int] = ...) -> None: ...

class AttributesInScope(_message.Message):
    __slots__ = ("object_handle", "attribute_handles")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class AttributesOutOfScope(_message.Message):
    __slots__ = ("object_handle", "attribute_handles")
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLES_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    attribute_handles: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, object_handle: _Optional[int] = ..., attribute_handles: _Optional[_Iterable[int]] = ...) -> None: ...

class ObjectInstanceNameReservationSucceeded(_message.Message):
    __slots__ = ("object_name",)
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    object_name: str
    def __init__(self, object_name: _Optional[str] = ...) -> None: ...

class ObjectInstanceNameReservationFailed(_message.Message):
    __slots__ = ("object_name",)
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    object_name: str
    def __init__(self, object_name: _Optional[str] = ...) -> None: ...

class MultipleObjectInstanceNameReservationSucceeded(_message.Message):
    __slots__ = ("object_names",)
    OBJECT_NAMES_FIELD_NUMBER: _ClassVar[int]
    object_names: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, object_names: _Optional[_Iterable[str]] = ...) -> None: ...

class MultipleObjectInstanceNameReservationFailed(_message.Message):
    __slots__ = ("requested_names", "colliding_names")
    REQUESTED_NAMES_FIELD_NUMBER: _ClassVar[int]
    COLLIDING_NAMES_FIELD_NUMBER: _ClassVar[int]
    requested_names: _containers.RepeatedScalarFieldContainer[str]
    colliding_names: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, requested_names: _Optional[_Iterable[str]] = ..., colliding_names: _Optional[_Iterable[str]] = ...) -> None: ...
