from rti.v1 import common_pb2 as _common_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetObjectClassHandleRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "class_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    CLASS_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    class_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., class_name: _Optional[str] = ...) -> None: ...

class GetObjectClassHandleResponse(_message.Message):
    __slots__ = ("class_handle",)
    CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    class_handle: int
    def __init__(self, class_handle: _Optional[int] = ...) -> None: ...

class GetObjectClassNameRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "class_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    class_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., class_handle: _Optional[int] = ...) -> None: ...

class GetObjectClassNameResponse(_message.Message):
    __slots__ = ("class_name",)
    CLASS_NAME_FIELD_NUMBER: _ClassVar[int]
    class_name: str
    def __init__(self, class_name: _Optional[str] = ...) -> None: ...

class GetAttributeHandleRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "class_handle", "attribute_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    class_handle: int
    attribute_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., class_handle: _Optional[int] = ..., attribute_name: _Optional[str] = ...) -> None: ...

class GetAttributeHandleResponse(_message.Message):
    __slots__ = ("attribute_handle",)
    ATTRIBUTE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    attribute_handle: int
    def __init__(self, attribute_handle: _Optional[int] = ...) -> None: ...

class GetAttributeNameRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "class_handle", "attribute_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    class_handle: int
    attribute_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., class_handle: _Optional[int] = ..., attribute_handle: _Optional[int] = ...) -> None: ...

class GetAttributeNameResponse(_message.Message):
    __slots__ = ("attribute_name",)
    ATTRIBUTE_NAME_FIELD_NUMBER: _ClassVar[int]
    attribute_name: str
    def __init__(self, attribute_name: _Optional[str] = ...) -> None: ...

class GetInteractionClassHandleRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "class_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    CLASS_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    class_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., class_name: _Optional[str] = ...) -> None: ...

class GetInteractionClassHandleResponse(_message.Message):
    __slots__ = ("class_handle",)
    CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    class_handle: int
    def __init__(self, class_handle: _Optional[int] = ...) -> None: ...

class GetInteractionClassNameRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "class_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    class_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., class_handle: _Optional[int] = ...) -> None: ...

class GetInteractionClassNameResponse(_message.Message):
    __slots__ = ("class_name",)
    CLASS_NAME_FIELD_NUMBER: _ClassVar[int]
    class_name: str
    def __init__(self, class_name: _Optional[str] = ...) -> None: ...

class GetParameterHandleRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "class_handle", "parameter_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    PARAMETER_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    class_handle: int
    parameter_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., class_handle: _Optional[int] = ..., parameter_name: _Optional[str] = ...) -> None: ...

class GetParameterHandleResponse(_message.Message):
    __slots__ = ("parameter_handle",)
    PARAMETER_HANDLE_FIELD_NUMBER: _ClassVar[int]
    parameter_handle: int
    def __init__(self, parameter_handle: _Optional[int] = ...) -> None: ...

class GetParameterNameRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "class_handle", "parameter_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    CLASS_HANDLE_FIELD_NUMBER: _ClassVar[int]
    PARAMETER_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    class_handle: int
    parameter_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., class_handle: _Optional[int] = ..., parameter_handle: _Optional[int] = ...) -> None: ...

class GetParameterNameResponse(_message.Message):
    __slots__ = ("parameter_name",)
    PARAMETER_NAME_FIELD_NUMBER: _ClassVar[int]
    parameter_name: str
    def __init__(self, parameter_name: _Optional[str] = ...) -> None: ...

class GetDimensionHandleRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "dimension_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    dimension_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., dimension_name: _Optional[str] = ...) -> None: ...

class GetDimensionHandleResponse(_message.Message):
    __slots__ = ("dimension_handle",)
    DIMENSION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    dimension_handle: int
    def __init__(self, dimension_handle: _Optional[int] = ...) -> None: ...

class GetDimensionNameRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "dimension_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    dimension_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., dimension_handle: _Optional[int] = ...) -> None: ...

class GetDimensionNameResponse(_message.Message):
    __slots__ = ("dimension_name",)
    DIMENSION_NAME_FIELD_NUMBER: _ClassVar[int]
    dimension_name: str
    def __init__(self, dimension_name: _Optional[str] = ...) -> None: ...

class GetDimensionUpperBoundRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "dimension_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    dimension_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., dimension_handle: _Optional[int] = ...) -> None: ...

class GetDimensionUpperBoundResponse(_message.Message):
    __slots__ = ("upper_bound",)
    UPPER_BOUND_FIELD_NUMBER: _ClassVar[int]
    upper_bound: int
    def __init__(self, upper_bound: _Optional[int] = ...) -> None: ...

class GetOrderTypeRequest(_message.Message):
    __slots__ = ("wire_version", "order_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    ORDER_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    order_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., order_name: _Optional[str] = ...) -> None: ...

class GetOrderTypeResponse(_message.Message):
    __slots__ = ("order_type",)
    ORDER_TYPE_FIELD_NUMBER: _ClassVar[int]
    order_type: int
    def __init__(self, order_type: _Optional[int] = ...) -> None: ...

class GetOrderNameRequest(_message.Message):
    __slots__ = ("wire_version", "order_type")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    ORDER_TYPE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    order_type: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., order_type: _Optional[int] = ...) -> None: ...

class GetOrderNameResponse(_message.Message):
    __slots__ = ("order_name",)
    ORDER_NAME_FIELD_NUMBER: _ClassVar[int]
    order_name: str
    def __init__(self, order_name: _Optional[str] = ...) -> None: ...

class GetTransportationTypeRequest(_message.Message):
    __slots__ = ("wire_version", "transportation_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    TRANSPORTATION_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    transportation_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., transportation_name: _Optional[str] = ...) -> None: ...

class GetTransportationTypeResponse(_message.Message):
    __slots__ = ("transportation_type",)
    TRANSPORTATION_TYPE_FIELD_NUMBER: _ClassVar[int]
    transportation_type: int
    def __init__(self, transportation_type: _Optional[int] = ...) -> None: ...

class GetTransportationNameRequest(_message.Message):
    __slots__ = ("wire_version", "transportation_type")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    TRANSPORTATION_TYPE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    transportation_type: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., transportation_type: _Optional[int] = ...) -> None: ...

class GetTransportationNameResponse(_message.Message):
    __slots__ = ("transportation_name",)
    TRANSPORTATION_NAME_FIELD_NUMBER: _ClassVar[int]
    transportation_name: str
    def __init__(self, transportation_name: _Optional[str] = ...) -> None: ...

class GetObjectInstanceHandleRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "object_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    object_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., object_name: _Optional[str] = ...) -> None: ...

class GetObjectInstanceHandleResponse(_message.Message):
    __slots__ = ("object_handle",)
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    object_handle: int
    def __init__(self, object_handle: _Optional[int] = ...) -> None: ...

class GetObjectInstanceNameRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "object_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    OBJECT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    object_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., object_handle: _Optional[int] = ...) -> None: ...

class GetObjectInstanceNameResponse(_message.Message):
    __slots__ = ("object_name",)
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    object_name: str
    def __init__(self, object_name: _Optional[str] = ...) -> None: ...
