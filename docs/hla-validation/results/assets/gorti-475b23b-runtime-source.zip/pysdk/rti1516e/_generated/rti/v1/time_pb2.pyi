from rti.v1 import common_pb2 as _common_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class EnableRegulationRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "lookahead")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOOKAHEAD_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    lookahead: float
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., lookahead: _Optional[float] = ...) -> None: ...

class DisableRegulationRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...

class EnableConstrainedRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...

class DisableConstrainedRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...

class NERRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "logical_time")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    logical_time: float
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., logical_time: _Optional[float] = ...) -> None: ...

class NMRARequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "logical_time")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    logical_time: float
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., logical_time: _Optional[float] = ...) -> None: ...

class TARRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "logical_time")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    logical_time: float
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., logical_time: _Optional[float] = ...) -> None: ...

class TARARequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "logical_time")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    logical_time: float
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., logical_time: _Optional[float] = ...) -> None: ...

class FQRRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "logical_time")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    logical_time: float
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., logical_time: _Optional[float] = ...) -> None: ...

class ModifyLookaheadRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "lookahead")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    LOOKAHEAD_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    lookahead: float
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., lookahead: _Optional[float] = ...) -> None: ...

class QueryFederateTimeRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...

class QueryFederateTimeResponse(_message.Message):
    __slots__ = ("logical_time",)
    LOGICAL_TIME_FIELD_NUMBER: _ClassVar[int]
    logical_time: float
    def __init__(self, logical_time: _Optional[float] = ...) -> None: ...

class QueryLookaheadResponse(_message.Message):
    __slots__ = ("lookahead",)
    LOOKAHEAD_FIELD_NUMBER: _ClassVar[int]
    lookahead: float
    def __init__(self, lookahead: _Optional[float] = ...) -> None: ...

class QueryLBTSRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ...) -> None: ...

class QueryLBTSResponse(_message.Message):
    __slots__ = ("lbts", "finite")
    LBTS_FIELD_NUMBER: _ClassVar[int]
    FINITE_FIELD_NUMBER: _ClassVar[int]
    lbts: float
    finite: bool
    def __init__(self, lbts: _Optional[float] = ..., finite: _Optional[bool] = ...) -> None: ...

class QueryGALTResponse(_message.Message):
    __slots__ = ("galt", "finite")
    GALT_FIELD_NUMBER: _ClassVar[int]
    FINITE_FIELD_NUMBER: _ClassVar[int]
    galt: float
    finite: bool
    def __init__(self, galt: _Optional[float] = ..., finite: _Optional[bool] = ...) -> None: ...

class QueryLITSResponse(_message.Message):
    __slots__ = ("lits", "finite")
    LITS_FIELD_NUMBER: _ClassVar[int]
    FINITE_FIELD_NUMBER: _ClassVar[int]
    lits: float
    finite: bool
    def __init__(self, lits: _Optional[float] = ..., finite: _Optional[bool] = ...) -> None: ...

class EnableAsynchronousDeliveryRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...

class DisableAsynchronousDeliveryRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ...) -> None: ...
