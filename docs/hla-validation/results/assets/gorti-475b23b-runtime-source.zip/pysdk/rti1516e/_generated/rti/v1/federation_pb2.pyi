from rti.v1 import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TransportMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TRANSPORT_MODE_UNSPECIFIED: _ClassVar[TransportMode]
    TRANSPORT_MODE_GRPC: _ClassVar[TransportMode]
    TRANSPORT_MODE_DDS: _ClassVar[TransportMode]
TRANSPORT_MODE_UNSPECIFIED: TransportMode
TRANSPORT_MODE_GRPC: TransportMode
TRANSPORT_MODE_DDS: TransportMode

class CreateFederationRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "fom_modules", "mode", "stall_timeout_seconds", "seed", "transport_mode")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FOM_MODULES_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    STALL_TIMEOUT_SECONDS_FIELD_NUMBER: _ClassVar[int]
    SEED_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_MODE_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    fom_modules: _containers.RepeatedCompositeFieldContainer[_common_pb2.FOMModule]
    mode: _common_pb2.Mode
    stall_timeout_seconds: float
    seed: int
    transport_mode: TransportMode
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., fom_modules: _Optional[_Iterable[_Union[_common_pb2.FOMModule, _Mapping]]] = ..., mode: _Optional[_Union[_common_pb2.Mode, str]] = ..., stall_timeout_seconds: _Optional[float] = ..., seed: _Optional[int] = ..., transport_mode: _Optional[_Union[TransportMode, str]] = ...) -> None: ...

class CreateFederationResponse(_message.Message):
    __slots__ = ("effective_seed", "federation_generation")
    EFFECTIVE_SEED_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_GENERATION_FIELD_NUMBER: _ClassVar[int]
    effective_seed: int
    federation_generation: int
    def __init__(self, effective_seed: _Optional[int] = ..., federation_generation: _Optional[int] = ...) -> None: ...

class DestroyFederationRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "expected_federation_generation")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_FEDERATION_GENERATION_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    expected_federation_generation: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., expected_federation_generation: _Optional[int] = ...) -> None: ...

class JoinFederationRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_name", "federate_type", "expected_federation_generation")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_FEDERATION_GENERATION_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_name: str
    federate_type: str
    expected_federation_generation: int
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_name: _Optional[str] = ..., federate_type: _Optional[str] = ..., expected_federation_generation: _Optional[int] = ...) -> None: ...

class JoinFederationResponse(_message.Message):
    __slots__ = ("federate_handle", "transport_mode", "dds_domain_id")
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_MODE_FIELD_NUMBER: _ClassVar[int]
    DDS_DOMAIN_ID_FIELD_NUMBER: _ClassVar[int]
    federate_handle: int
    transport_mode: TransportMode
    dds_domain_id: int
    def __init__(self, federate_handle: _Optional[int] = ..., transport_mode: _Optional[_Union[TransportMode, str]] = ..., dds_domain_id: _Optional[int] = ...) -> None: ...

class ResignFederationRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "action")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    action: _common_pb2.ResignAction
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., action: _Optional[_Union[_common_pb2.ResignAction, str]] = ...) -> None: ...

class ListFederationsRequest(_message.Message):
    __slots__ = ("wire_version",)
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ...) -> None: ...

class ListFederationsResponse(_message.Message):
    __slots__ = ("federations",)
    FEDERATIONS_FIELD_NUMBER: _ClassVar[int]
    federations: _containers.RepeatedCompositeFieldContainer[FederationSummary]
    def __init__(self, federations: _Optional[_Iterable[_Union[FederationSummary, _Mapping]]] = ...) -> None: ...

class FederationSummary(_message.Message):
    __slots__ = ("name", "mode", "federates_joined", "federation_generation")
    NAME_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    FEDERATES_JOINED_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_GENERATION_FIELD_NUMBER: _ClassVar[int]
    name: str
    mode: _common_pb2.Mode
    federates_joined: int
    federation_generation: int
    def __init__(self, name: _Optional[str] = ..., mode: _Optional[_Union[_common_pb2.Mode, str]] = ..., federates_joined: _Optional[int] = ..., federation_generation: _Optional[int] = ...) -> None: ...

class ListFederationMembersRequest(_message.Message):
    __slots__ = ("wire_version", "federation_name")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ...) -> None: ...

class ListFederationMembersResponse(_message.Message):
    __slots__ = ("members",)
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    members: _containers.RepeatedCompositeFieldContainer[FederationMember]
    def __init__(self, members: _Optional[_Iterable[_Union[FederationMember, _Mapping]]] = ...) -> None: ...

class FederationMember(_message.Message):
    __slots__ = ("federate_handle", "federate_name", "federate_type")
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    federate_handle: int
    federate_name: str
    federate_type: str
    def __init__(self, federate_handle: _Optional[int] = ..., federate_name: _Optional[str] = ..., federate_type: _Optional[str] = ...) -> None: ...
