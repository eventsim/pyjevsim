from rti.v1 import common_pb2 as _common_pb2
from rti.v1 import object_pb2 as _object_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ConfirmedObjectRequest(_message.Message):
    __slots__ = ("sequence", "open", "attribute_update", "interaction")
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    OPEN_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_UPDATE_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_FIELD_NUMBER: _ClassVar[int]
    sequence: int
    open: ConfirmedObjectOpen
    attribute_update: _object_pb2.UpdateAttributeValuesRequest
    interaction: _object_pb2.SendInteractionRequest
    def __init__(self, sequence: _Optional[int] = ..., open: _Optional[_Union[ConfirmedObjectOpen, _Mapping]] = ..., attribute_update: _Optional[_Union[_object_pb2.UpdateAttributeValuesRequest, _Mapping]] = ..., interaction: _Optional[_Union[_object_pb2.SendInteractionRequest, _Mapping]] = ...) -> None: ...

class ConfirmedObjectOpen(_message.Message):
    __slots__ = ("wire_version", "federation_name", "federate_handle", "expected_federation_generation", "transport_diagnostics")
    WIRE_VERSION_FIELD_NUMBER: _ClassVar[int]
    FEDERATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FEDERATE_HANDLE_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_FEDERATION_GENERATION_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_DIAGNOSTICS_FIELD_NUMBER: _ClassVar[int]
    wire_version: _common_pb2.WireVersion
    federation_name: str
    federate_handle: int
    expected_federation_generation: int
    transport_diagnostics: bool
    def __init__(self, wire_version: _Optional[_Union[_common_pb2.WireVersion, str]] = ..., federation_name: _Optional[str] = ..., federate_handle: _Optional[int] = ..., expected_federation_generation: _Optional[int] = ..., transport_diagnostics: _Optional[bool] = ...) -> None: ...

class ConfirmedObjectResult(_message.Message):
    __slots__ = ("sequence", "error_status", "server_service_ns", "previous_ack_send_ns")
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    ERROR_STATUS_FIELD_NUMBER: _ClassVar[int]
    SERVER_SERVICE_NS_FIELD_NUMBER: _ClassVar[int]
    PREVIOUS_ACK_SEND_NS_FIELD_NUMBER: _ClassVar[int]
    sequence: int
    error_status: bytes
    server_service_ns: int
    previous_ack_send_ns: int
    def __init__(self, sequence: _Optional[int] = ..., error_status: _Optional[bytes] = ..., server_service_ns: _Optional[int] = ..., previous_ack_send_ns: _Optional[int] = ...) -> None: ...
